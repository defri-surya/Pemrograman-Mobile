package com.piusanggoro.belajarrecyclerview

data class ExampleItem(val imageResource: Int, val text1: String, val text2: String)
